package com.capstore.boot.service;

import java.util.List;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.boot.dao.BrandDao;
import com.capstore.boot.dao.CategoryDao;
import com.capstore.boot.dao.IMerchDao;
import com.capstore.boot.dao.InventoryDao;
import com.capstore.boot.model.Brand;
import com.capstore.boot.model.Category;
import com.capstore.boot.model.Inventory;
import com.capstore.boot.model.Merchant;


@Service("inventoryServiceMerch")
@Transactional
public class MerchInventoryServiceImpl implements MerchInventoryService {
	@Autowired
    private InventoryDao inventoryDao;
	@Autowired
	private CategoryDao categoryDao;
	@Autowired
	private BrandDao brandDao;
	@Autowired
	private IMerchDao merchDao;
	
	@Override
    public List<Inventory> getAllInventory(){
    	return (List<Inventory>) inventoryDao.findAll();
    }

	@Override
	public void save(Inventory product) {
		inventoryDao.save(product);
	}
	
	@Override
	public void delete(Integer productId) {
		// TODO Auto-generated method stub
		inventoryDao.deleteById(productId);
	}

	@Override
	public List<Inventory> getAll() {
		// TODO Auto-generated method stub
		return inventoryDao.findAll();
	}

	@Override
	public List<Brand> getAllBrands() {
		
		return brandDao.findAll();
	}

	@Override
	public List<Category> getAllCategories() {
		
		return categoryDao.findAll();
	}

	@Override
	public Merchant getMerch(int merchantId) {
		
		return merchDao.getOne(merchantId);
	}

	@Override
	public List<Merchant> getAllMerch() {
	
		return merchDao.findAll();
	}

	@Override
	public Inventory getProduct(String productName) {
		// TODO Auto-generated method stub
		return inventoryDao.findOne(productName);
	}

	/*@Override
	public Inventory findProduct(Integer productId) {
		// TODO Auto-generated method stub
	 inventoryDao.findProduct(productId);
	}
	*/
	
	
	
}
