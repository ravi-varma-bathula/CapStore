package com.capstore.boot.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;



@Entity
@Component
public class InvoiceProduct {
	@Id
	@GeneratedValue(generator="cust1",strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(name="cust1",sequenceName="InvoiceProduct1",initialValue=1,allocationSize=1)
private int invoicepId;
	@OneToMany(fetch=FetchType.LAZY)
private List<Inventory> inventory;
	@OneToOne(targetEntity = GenerateInvoice.class, mappedBy = "invoiceProduct")
	private GenerateInvoice generateInvoice;
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="discountId")
	private Discount discount;
	public InvoiceProduct() {
		super();
		System.out.println("invoice product");
	}

	
	public int getInvoicepId() {
		return invoicepId;
	}


	public void setInvoicepId(int invoicepId) {
		this.invoicepId = invoicepId;
	}


	public InvoiceProduct(int invoicepId, GenerateInvoice generateInvoice) {
		super();
		this.invoicepId = invoicepId;
		this.generateInvoice = generateInvoice;
	}

	public GenerateInvoice getGenerateInvoice() {
		return generateInvoice;
	}

	public void setGenerateInvoice(GenerateInvoice generateInvoice) {
		this.generateInvoice = generateInvoice;
	}

	public List<Inventory> getInventory() {
		return inventory;
	}

	public void setInventory(List<Inventory> inventory) {
		this.inventory = inventory;
	}

	public Discount getDiscount() {
		return discount;
	}

	public void setDiscount(Discount discount) {
		this.discount = discount;
	}

	public InvoiceProduct(int invoicepId, List<Inventory> inventory, GenerateInvoice generateInvoice,
			Discount discount) {
		super();
		this.invoicepId = invoicepId;
		this.inventory = inventory;
		this.generateInvoice = generateInvoice;
		this.discount = discount;
	}

	}
