package com.capstore.boot.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.boot.dao.ILoginAdminDao;
import com.capstore.boot.model.Admin;



@Service("adminLoginService")
public class AdminLoginServiceImpl implements IAdminLogin {

	@Autowired
	 ILoginAdminDao loginAdminDao;
	
	@Override
	public Admin getAdmin(String username, String password) {
		
		return loginAdminDao.getAdmin(username, password);
	}

}
