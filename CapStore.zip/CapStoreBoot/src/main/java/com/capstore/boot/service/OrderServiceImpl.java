package com.capstore.boot.service;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.boot.dao.OrderDao;
import com.capstore.boot.model.Customer;
import com.capstore.boot.model.Order;

@Service("orderService")
public class OrderServiceImpl implements OrderService {

	@Autowired
	OrderDao orderDao;

	LocalDate date = java.time.LocalDate.now();
	LocalDate date1 = java.time.LocalDate.now().plusDays(6);

	

	/*@Override
	public Order findByorderId(int orderId) {
	Order getOrder= orderDao.findByorderId(orderId);
	return getOrder;
	}
*/
	@Override
	public Order create(Integer cid, Integer productId, String productName, Integer price) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void save(Order o) {
		orderDao.save(o);
	}


}
