package com.capstore.boot.service;

import java.util.List;

import com.capstore.boot.model.Address;



public interface IAddressService {

	public List<Address> getAllAddress();
}
