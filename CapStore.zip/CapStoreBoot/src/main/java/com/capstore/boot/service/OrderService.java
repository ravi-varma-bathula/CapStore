package com.capstore.boot.service;

import com.capstore.boot.model.Order;

public interface OrderService {
	Order create(Integer cid,Integer productId, String productName, Integer price);
	//	Order findByorderId(int orderId);
	void save(Order o);
}
