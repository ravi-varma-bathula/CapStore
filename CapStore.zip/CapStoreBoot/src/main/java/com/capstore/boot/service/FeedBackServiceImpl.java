package com.capstore.boot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.boot.dao.IFeedBackDao;
import com.capstore.boot.model.Customer;
import com.capstore.boot.model.FeedBack;
import com.capstore.boot.model.Inventory;
import com.capstore.boot.model.Merchant;




@Service("iFeedbackService")
public class FeedBackServiceImpl implements IFeedbackService
{
	@Autowired
	IFeedBackDao feedbackDao;
   
	@Autowired
	InventoryService inventoryService;
	
	@Autowired
	CustomerService customerService;
	
	@Autowired
	MerchantService merchantService;
	
	@Override
	public List<FeedBack> getAll(int pid) 
	{
		Inventory p = inventoryService.getProductByid(pid);
		return p.getFeedback();
	}
	
	@Override
	public double avgrating(int pid) 
	{
		List<FeedBack> list = feedbackDao.findAll();
		int total=0,count=0;
		
		for(FeedBack f:list)
		{
			if(f.getInventory().getProductId()==pid)
			{
			total=total+f.getProductRating();
			count++;
			}
		}
		if(count!=0)
		{
		double avg=total/count;
		return avg;
		}
		else 
			return 0;
	}
	
	@Override
	public FeedBack givefeedback(String comments,int rate, int cid, int pid, int mid)
	{
		FeedBack f=new FeedBack();
		
		Merchant merchant = merchantService.findMerchantById(mid);
		Inventory p = inventoryService.getProductByid(pid);
		Customer c = customerService.findOne(cid);
		
		f.setComments(comments);
		f.setMerchant(merchant);
		f.setInventory(p);
		f.setCustomer(c);
		f.setProductRating(rate);
		
		feedbackDao.save(f);
		
		return f;
	}
	
	
	@Override
	public double merchantrating(int mid)
	{
		List<FeedBack> list=feedbackDao.findAll();
		
		int total=0,count=0;
		for(FeedBack f:list)
		{
			if(f.getMerchant().getMerchantId()==mid)
			{
				total=total+f.getProductRating();
				count++;	
			}
			
		}
		if(count!=0)
		{
		double Mavg=total/count;
		return Mavg;
		}
		else 
		return 0;
		
	}
	}
