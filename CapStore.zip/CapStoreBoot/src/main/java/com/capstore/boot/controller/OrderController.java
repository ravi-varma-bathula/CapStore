package com.capstore.boot.controller;



import java.time.LocalDate;
import java.util.ArrayList;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.catalina.Store;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.servlet.ModelAndView;

import com.capstore.boot.model.Customer;
import com.capstore.boot.model.Inventory;
import com.capstore.boot.model.Order;
import com.capstore.boot.service.InventoryService;
import com.capstore.boot.service.OrderService;


@Controller
public class OrderController {

	@Autowired
	OrderService orderService;

	@Autowired
	InventoryService inventoryService;
	/*@Autowired
	CapStoreService capStoreService;
*/
	double p;
	
	public OrderController() {
		System.out.println("Order Controller");
	}

	@RequestMapping("/proceedtobuy")
	public ModelAndView orderdetails(HttpServletRequest request) {
		ModelAndView modelView = new ModelAndView();
		HttpSession session = request.getSession();
		List<Inventory> list = (List<Inventory>) session.getAttribute("list");
		// System.out.println(list);
		int i = 1;
		
	int Cartqty=	Integer.parseInt(request.getParameter("qty" + (i)));
		double price;
		boolean status=true;
		List<String> stock=new ArrayList();
		List<Integer> quant=new ArrayList();
		try
		{
		for (Inventory P : list) {
			if ((P.getQuantity())>=Cartqty) {
			
				System.out.println(i);
				stock.add("Available");
				session.setAttribute("status", stock);
				 p=P.getPrice();
				 price=p*Cartqty;
				quant.add((int) (p*Cartqty));
				i++;
			}else {
				i++;
				
				modelView.addObject("msg", "Out of Stock");
				modelView.setViewName("CartPage");
				
				
			//	stock.add("Out of Stock");
				status=false;
			}
		
		}
		System.out.println(stock);
	
		System.out.println(status);
		if(status) 
		{
			modelView.addObject("quantity1", stock);
			session.setAttribute("quant",quant);
			System.out.println(quant);
			int product=1,index = 0;
			double totalprice=0;
			for(Inventory P : list)
			{
				int qty=Integer.parseInt(request.getParameter("qty" + (product)));
				int oldqty=P.getQuantity()-qty;
				P.setQuantity(oldqty);
				System.out.println(qty);
				
				inventoryService.save1(P);;
				
				 p=P.getPrice();
				 price=p*qty;
				 totalprice=totalprice+price;
				 int productId = list.get(index).getProductId();
					String productName = list.get(index).getProductName();
					double price1 = list.get(index).getPrice() * qty;
				
					
				Customer customer= (Customer) session.getAttribute("user");
					if(customer!=null) {
						Order o = new Order();
						o.setCustomer(customer);
						
						LocalDate date = java.time.LocalDate.now();
						LocalDate date1 = java.time.LocalDate.now().plusDays(6);
						o.setDeliveredDate(date1);
						o.setOrderDate(date);
				
						/*	o.setDeliveryStatus(deliveryStatus);
						o.setManagingCart(managingCart);
						o.setReturnOrder(returnOrder);
						o.setTransaction(transaction);*/
					
						orderService.save(o);
						session.setAttribute("orderDetails",o);
						
						modelView.setViewName("OrderPage");
						
						product++;
						index++;
					}else {
						System.out.println("Customer Not Found From The Session");
					}
					
				
		
			}
			
			
		}else 
		{
			modelView.setViewName("CartPage");
		}}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			modelView.setViewName("CartPage");
		}
		return modelView;
	}
	
	@RequestMapping("/final")
	public String finalp() {
		return "final";
	}

	@RequestMapping("/continue")
	public String payamount(HttpServletRequest request) {
		return "final";
		
	}

	
	
}
