package com.cg.capstore.service;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.dao.OrderDao;
import com.cg.capstore.dto.Order;

@Service("orderService")
public class OrderServiceImpl implements OrderService {

	@Autowired
	OrderDao orderDao;

	LocalDate date = java.time.LocalDate.now();
	LocalDate date1 = java.time.LocalDate.now().plusDays(6);

	@Override
	public Order create(Integer cid,Integer productId, String productName, Integer price) {
		Order o = new Order();
		o.setCustomerid(cid);
		o.setPdtid(productId);
		o.setPdtname(productName);
		o.setPrice(price);
		o.setOrderDate(date);
		o.setDeliveredDate(date1);
		orderDao.save(o);
		return o;
	}

	@Override
	public Order findByorderId(int orderId) {
	Order getOrder= orderDao.findByorderId(orderId);
	return getOrder;
	}


}
