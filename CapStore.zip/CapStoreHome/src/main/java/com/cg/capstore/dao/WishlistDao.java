package com.cg.capstore.dao;


import javax.transaction.Transactional;

import com.cg.capstore.dto.Wishlist;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository("dao")
public interface WishlistDao extends JpaRepository<Wishlist,String>{
	
	

}

