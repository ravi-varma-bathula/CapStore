package com.cg.capstore.service;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.dao.CouponDao;
import com.cg.capstore.dto.coupon;
@Service("couponServiceImpl")
public class CouponServiceImpl implements ICouponService {

	@Autowired
	CouponDao dao;

	@Override
	public List<coupon> getAllCoupons() {
		List coupons=dao.findAll();
		return coupons;
	}

	
	@Override
	public coupon validateCoupon(String name) {
		coupon c=dao.findBycouponCode( name);
		return c;
	}

	@org.springframework.transaction.annotation.Transactional
	@Override
	public coupon addCoupon(String cname, double amount, String desc, Date idate, Date edate) {
		if(dao.findBycouponCode(cname)==null) {
		coupon status=dao.save(new coupon(cname,amount,desc,idate,edate));
		return status;
		}else
		{
			return null;
		}
	
		
	}


	@Override
	public void deleteCoupon(String couponid) {
		int cid= Integer.parseInt(couponid);
		dao.deleteById(cid);
	}


	@Override
	public coupon findBycouponCode(String name) {
	coupon c =dao.findBycouponCode(name);
		return c;
	}
	
}
