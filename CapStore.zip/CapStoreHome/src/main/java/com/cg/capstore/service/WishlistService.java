package com.cg.capstore.service;

import java.util.List;
import java.util.Optional;

import com.cg.capstore.dto.Wishlist;

public interface WishlistService {
	public List<Wishlist> getAll();
	public Wishlist getWishlistDetails(String user_Id);
	public boolean delete(String user_Id);
	public Wishlist add(Wishlist wishlist);
	public Wishlist update(Wishlist wishlist);
}
