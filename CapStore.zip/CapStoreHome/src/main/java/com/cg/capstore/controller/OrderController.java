package com.cg.capstore.controller;



import java.util.ArrayList;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.servlet.ModelAndView;

import com.cg.capstore.dto.Order;
import com.cg.capstore.dto.Store;
import com.cg.capstore.service.CapStoreService;
import com.cg.capstore.service.OrderService;

@Controller
public class OrderController {

	@Autowired
	OrderService orderService;
	@Autowired
	CapStoreService capStoreService;

	int p;
	
	public OrderController() {
		System.out.println("Order Controller");
	}

	@RequestMapping("/proceedtobuy")
	public ModelAndView orderdetails(HttpServletRequest request) {
		ModelAndView modelView = new ModelAndView();
		HttpSession session = request.getSession();
		List<Store> list = (List<Store>) session.getAttribute("list");
		// System.out.println(list);
		int i = 1;
		Integer price;
		boolean status=true;
		List<String> stock=new ArrayList();
		List<Integer> quant=new ArrayList();
		try
		{
		for (Store P : list) {
			if (P.getProductQuantity().compareTo(Integer.parseInt(request.getParameter("qty" + (i))))>=0) {
				int qty=Integer.parseInt(request.getParameter("qty" + (i )));
				System.out.println(i);
				stock.add("Available");
				session.setAttribute("status", stock);
				 p=P.getProductPrice();
				 price=p*qty;
				quant.add(p*qty);
				i++;
			}else {
				i++;
				
				modelView.addObject("msg", "Out of Stock");
				modelView.setViewName("CartPage");
				
				
			//	stock.add("Out of Stock");
				status=false;
			}
		
		}
		System.out.println(stock);
	
		System.out.println(status);
		if(status) 
		{
			modelView.addObject("quantity1", stock);
			session.setAttribute("quant",quant);
			System.out.println(quant);
			int product=1,index = 0;
			double totalprice=0;
			for(Store P:list)
			{
				int qty=Integer.parseInt(request.getParameter("qty" + (product)));
				int oldqty=P.getProductQuantity()-qty;
				P.setProductQuantity(oldqty);
				System.out.println(qty);
				capStoreService.update(P);
				 p=P.getProductPrice();
				 price=p*qty;
				 totalprice=totalprice+price;
				 int productId = list.get(index).getProductId();
					String productName = list.get(index).getProductName();
					Integer price1 = list.get(index).getProductPrice() * qty;
				
					Order o = orderService.create(103,productId, productName, price1);
					session.setAttribute("orderDetails",o);
				modelView.setViewName("OrderPage");
			product++;
			index++;
			}
			
			
		}else 
		{
			modelView.setViewName("CartPage");
		}}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			modelView.setViewName("CartPage");
		}
		return modelView;
	}
	
	@RequestMapping("/final")
	public String finalp() {
		return "final";
	}

	@RequestMapping("/continue")
	public String payamount(HttpServletRequest request) {
		return "final";
		
	}

	
	
}
