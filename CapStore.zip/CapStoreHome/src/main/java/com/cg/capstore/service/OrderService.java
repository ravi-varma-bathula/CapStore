package com.cg.capstore.service;

import com.cg.capstore.dto.Order;

public interface OrderService {
	Order create(Integer cid,Integer productId, String productName, Integer price);
	Order findByorderId(int orderId);
}
