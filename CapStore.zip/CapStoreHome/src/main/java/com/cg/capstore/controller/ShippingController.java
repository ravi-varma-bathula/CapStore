package com.cg.capstore.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;


import com.cg.capstore.dto.Address;
import com.cg.capstore.dto.Store;
import com.cg.capstore.service.IAddressService;
import com.cg.capstore.service.IShippingService;

@Controller
public class ShippingController {

	@Autowired
	IShippingService shippingService;
	@Autowired	
	IAddressService addressService;

	
	@RequestMapping("/shipmentdetails")
	public ModelAndView ShippingDetails(HttpServletRequest request) {
		
		ModelAndView modelAndView = new ModelAndView();
		List<Address> list = addressService.findBycustomerId(1);
		
		if(list!=null) {
		HttpSession session = request.getSession();	
		session.setAttribute("Addresslist", list);
		modelAndView.setViewName("OrderPage");
			return modelAndView;
			
			
		}else {
			
			modelAndView.addObject("msg","Please Provide Delivery Address");
			modelAndView.setViewName("NewAddress");
		
			return modelAndView;
		
		}
		
		
		
		
	}

	@RequestMapping("/NewAddress")
	public String TakeNewAddress(){
		return "NewAddress";
	
	}
	
	@RequestMapping("/SaveAddress")
	public String AddNewAddress(HttpServletRequest request) {
		
		String houseNumber= request.getParameter("housenumber");
		String streetnum= request.getParameter("streetnumber");
		String City= request.getParameter("cityname");
		String ZipCode= request.getParameter("zipcode");
		String State= request.getParameter("stateName");
		String Country= request.getParameter("countryname");
		
		
		Address newAddress=new Address();
		
		newAddress.setCity(City);
		newAddress.setCountry(Country);
	
		
		newAddress.setCustomer(1);
	
		
		newAddress.setState(State);
		int streetnumber = Integer.parseInt(streetnum);
		newAddress.setStreetNumber(streetnumber);
		int zipc = Integer.parseInt(ZipCode);
		newAddress.setZipcode(zipc);
		
		addressService.save(newAddress);
	
		return "TransactionPage";
		
		
		
		
	}
	
	
}
