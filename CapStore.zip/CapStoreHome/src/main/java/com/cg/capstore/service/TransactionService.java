package com.cg.capstore.service;

import com.cg.capstore.dto.Order;
import com.cg.capstore.dto.Transaction;

public interface TransactionService {
	public Transaction findBytransactionId(int transactionId);
	public void saveTransaction(Transaction tr);
	public Order findByorderId(int orderId);
	
	
}
