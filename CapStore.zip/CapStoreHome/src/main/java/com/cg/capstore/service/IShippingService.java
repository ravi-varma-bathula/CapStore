package com.cg.capstore.service;

import com.cg.capstore.dto.Shipping;

public interface IShippingService {

	public Shipping findByshippingId(int id);
	public boolean Save(Shipping s);
	
}
