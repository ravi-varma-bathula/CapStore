package com.cg.capstore.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.capstore.dto.Address;
import com.cg.capstore.dto.coupon;
import com.cg.capstore.service.IAddressService;
import com.cg.capstore.service.ICouponService;

@Controller("couponController")
public class CouponController {

	@Autowired
	ICouponService service;
	
	@Autowired	
	IAddressService addressService;
	
	@RequestMapping("/coupon")
	public String adminpage() {
		return "coupon";
	}
	@RequestMapping("/addcoupon")
	public String couponregister() {
		return "addcoupon";
	}
	
	@RequestMapping("/addcoupons")
	public  String  addcoupons(HttpServletRequest request,Model model) throws ParseException {
		
		String cname = request.getParameter("cname");
		String desc = request.getParameter("desc");
		Date idate=new SimpleDateFormat("dd/MM/yyyy").parse(request.getParameter("idate"));
		Date edate=new SimpleDateFormat("dd/MM/yyyy").parse(request.getParameter("edate"));
		double amount =Double.parseDouble(request.getParameter("amount"));
		coupon c= service.findBycouponCode(cname);
		if(c==null) {
			c=service.addCoupon(cname,amount,desc,idate,edate);
			if(c!=null)
				return "coupon";
			else
				return "addcoupons";
		}else {
			model.addAttribute("msg", "Coupon Already Exists In Please Enter A new Coupon");
			return "coupon";
		}
	
		
	}
	
@RequestMapping("/viewall")
public String listCoupon(Model m) throws IOException {

List<coupon> listCoupon = service.getAllCoupons();
System.out.println(listCoupon);
m.addAttribute("listCoupon", listCoupon);
		
		return "viewall";
	}

@RequestMapping("/apply")
public String applyCoupon(HttpServletRequest request) {
	HttpSession session=request.getSession();
	ModelAndView modelAndView=new ModelAndView();
	double totalprice=(double) session.getAttribute("totalprice");

/*	
	List<Address> list = addressService.findBycustomerId(1);
	if(list!=null) {
		
		session.setAttribute("Addresslist", list);
		
	}*/
	
	String code=request.getParameter("cname");
	
	session.setAttribute("cname", code);
	coupon c=service.validateCoupon(code);
	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	Date cdate = new Date();
	System.out.println(cdate);
	double finalamount;
	if(c!=null ) {
	Date idate=c.getIssueDate();
	Date  edate=c.getExpiryDate();
		if(idate.compareTo(cdate) * cdate.compareTo(edate) >= 0) {
	 finalamount=totalprice-c.getCouponAmount();
			session.setAttribute("totalprice", finalamount);
				//session.setAttribute("couponamount", couponamount);
	/*List<Address> list = addressService.findBycustomerId(1);
		
		if(list!=null) {
		HttpSession session = request.getSession();	
		session.setAttribute("Addresslist", list);
		modelAndView.setViewName("OrderPage");
			return modelAndView;
			
			
		}else {
			
			modelAndView.addObject("msg","Please Provide Delivery Address");
			modelAndView.setViewName("NewAddress");
		
			return modelAndView;
		
		}*/		
		}
		
	}
	return "final";
	
}
@RequestMapping("/order")
public String orderpage() {
	return "order";
}
/*@RequestMapping("/final")
public String finalp() {
	return "final";
}*/
@RequestMapping("/pay")
public String payamount(HttpServletRequest request) {
	return "TransactionPage";
	
}

@RequestMapping("/deletecoupon")
public  ModelAndView  deletecoupons(HttpServletRequest request,Model m)
{ModelAndView modelAndView = new ModelAndView();
	String couponid=request.getParameter("couponid");
	service.deleteCoupon(couponid);
	
	List<coupon> listCoupon = service.getAllCoupons();
	System.out.println(listCoupon);
	m.addAttribute("listCoupon", listCoupon);
	
	modelAndView.setViewName("viewall");
	return modelAndView;
	}
}
