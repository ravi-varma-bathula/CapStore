package com.cg.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.capstore.dto.Store;


@Repository("capStoreDao")
public interface CapStoreDao extends JpaRepository<Store,Integer>
{
	
	List<Store>  findListByCategoryId(Integer cat);
	
	List<Store>  findByProductName(String name);
	 Store findByProductId(Integer productId);

}
