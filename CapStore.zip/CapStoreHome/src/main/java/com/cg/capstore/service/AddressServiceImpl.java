package com.cg.capstore.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.dao.AddressDao;
import com.cg.capstore.dto.Address;
@Service("addressService")
public class AddressServiceImpl implements IAddressService {

	
	@Autowired
	AddressDao addressDao;
	
	
	@Override
	public List<Address> findBycustomerId(int customerId) {
		List<Address> addressList= new ArrayList<>();
		addressList = addressDao.findBycustomerId(customerId);
		if(addressList!=null) {
			
		return addressList;	
		}
		
		
		return null;
	}


	@Override
	public void save(Address address) {
		addressDao.save(address);
		
	}

}
