package com.cg.capstore.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.capstore.dto.Store;
import com.cg.capstore.service.CapStoreService;

@Controller
public class CapStoreController {
	@Autowired
	CapStoreService capStoreService;

	@RequestMapping(value = "all")
	public String start() {
		return "home";

	}

	@RequestMapping(value = "/")
	public ModelAndView home(HttpServletRequest request) {
		ModelAndView modelView = new ModelAndView();

		HttpSession session = request.getSession();

		List<Store> productlist = capStoreService.getAll();
		modelView.addObject("plist", productlist);

		session.setAttribute("prodlist", productlist);

		System.out.println(productlist);
		System.out.println("helooooooo");
		modelView.setViewName("index");
		return modelView;
	}

	@RequestMapping(value = "products")
	public ModelAndView Categories(@ModelAttribute("my") Store s, @RequestParam("id") int i) {
		List<Store> list = capStoreService.getAllProducts(i);

		return new ModelAndView("categories", "data", list);

	}

	@RequestMapping(value = "/search")
	public ModelAndView search(HttpServletRequest request, @RequestParam("sss") String name) {
		ModelAndView modelView = new ModelAndView();

		HttpSession session = request.getSession();

		List<Store> productlist = capStoreService.getProductByName(name);

		session.setAttribute("prodlist", productlist);
		System.out.println(productlist);
		System.out.println("helooooooo");
		modelView.setViewName("index");
		return modelView;
	}

	@RequestMapping(value = "/str")
	public ModelAndView sort(HttpServletRequest request, @RequestParam("p") String option) {
		ModelAndView modelView = new ModelAndView();

		HttpSession session = request.getSession();

		/*
		 * List<Store> productlist = capStoreService.getProductByName(name);
		 * 
		 * 
		 * session.setAttribute("prodlist", productlist);
		 * System.out.println(productlist);
		 */
		List<Store> list = (List<Store>) session.getAttribute("prodlist");

		System.out.println(option);

		if (option.equals("noofviews")) {

			Comparator<Store> comp = (i1, i2) -> Double.compare(i2.getNoOfViews(), i1.getNoOfViews());

			Collections.sort(list, comp);

		} else if (option.equals("lowtohigh")) {

			Comparator<Store> comp = (i1, i2) -> Double.compare(i1.getProductPrice(), i2.getProductPrice());

			Collections.sort(list, comp);

		} else {

			Comparator<Store> comp = (i1, i2) -> Double.compare(i2.getProductPrice(), i1.getProductPrice());

			Collections.sort(list, comp);
		}
		modelView.setViewName("index");
		return modelView;
	}

	/*
	 * @RequestMapping(value="products?id=10") public ModelAndView showData(Model
	 * model){ List<Store> allElectronics= service.showAllElectronics();
	 * model.addAttribute("Mobiles");
	 * 
	 * return new ModelAndView("Electronicproducts");
	 * 
	 * }
	 */

	@RequestMapping("/CartPage")
	public String cart() {
		return "CartPage";

	}
	@RequestMapping(value = "/cartadd")
	public ModelAndView editCustomer(@RequestParam(value = "cart", required = false) String checkboxValue,
			HttpServletRequest request) {
		ModelAndView modelView = new ModelAndView();
		HttpSession session = request.getSession();

		String ar[] = checkboxValue.split(",");
		int[] array = Arrays.asList(ar).stream().mapToInt(Integer::parseInt).toArray();
		List<Store> list = new ArrayList();
		for (int i : array) {
			System.out.println(i);
			list.add(capStoreService.findByProductId(i));
		}

		if (list != null) {
			session.setAttribute("list", list);
		}
		modelView.setViewName("CartPage");
		return modelView;
	}

	/*@RequestMapping("/removefromcart")
	public ModelAndView remove(@RequestParam("remove") Integer button, HttpServletRequest request,Model model) {
		ModelAndView modelView = new ModelAndView();
		HttpSession session = request.getSession();
		List<Store> s = (List<Store>) session.getAttribute("list");
		try {
			
			for (Store i : s) {
				if (i.getProductId() == button) {
					s.remove(i);
				}
			}
			System.out.println(s);
			model.addAttribute("list",s);
			modelView.setViewName("CartPage");
		} catch (NullPointerException ne) {
			modelView.addObject("msg", "empty cart");
			session.setAttribute("list", s);
			modelView.setViewName("OrderPage");
		}
		
		return modelView;
	}*/
	
	@RequestMapping("/removefromcart")
	public ModelAndView remove(@RequestParam("pid") int pid,HttpServletRequest request)
	{
		ModelAndView modelView = new ModelAndView();
		HttpSession session = request.getSession();
		List<Store> s = (List<Store>) session.getAttribute("list");
          try {
			
			for (Store i : s) {
				if(s.size()==-1) break;
				if (i.getProductId() == pid) {
					s.remove(i);
				}
			}
			System.out.println(s);
			modelView.setViewName("CartPage");
		} catch (Exception ne) {
			modelView.addObject("msg", "empty cart");
			session.setAttribute("list", s);
			modelView.setViewName("CartPage");
		//	ne.printStackTrace();
		}
		return modelView;
	}
	
	@RequestMapping("/wishlistpage")
	public String wish() {
		return "wishlistpage";
	}

	@RequestMapping(value = "/wish")
	public ModelAndView editCustomer1(@RequestParam(value = "wishlist", required = false)String checkboxValue,HttpServletRequest request) 
	{
		ModelAndView modelView = new ModelAndView();
		HttpSession session = request.getSession();
		
		String ar[]=checkboxValue.split(",");
		int[] array = Arrays.asList(ar).stream().mapToInt(Integer::parseInt).toArray();
		List<Store> list1=new ArrayList();
	    for(int i: array) {
	    	System.out.println(i);
	    	list1.add(capStoreService.findByProductId(i));
	    	
	    }
		
	  if(list1 != null)
	  {
		 session.setAttribute("list1", list1);
	  }
	  modelView.setViewName("home");
	  return modelView;
	}
	
}
