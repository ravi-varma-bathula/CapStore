package com.cg.capstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.capstore.dto.Shipping;

@Repository("shippingDao")
public interface IShippingDao extends JpaRepository<Shipping, Integer>{
	
	public Shipping findByshippingId(int id);
	public Shipping save(Shipping s);
	

}
