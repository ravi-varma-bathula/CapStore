package com.cg.capstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.dao.IShippingDao;
import com.cg.capstore.dto.Shipping;
@Service("shippingService")
public class ShippingServiceImpl implements IShippingService {

	
	@Autowired
	IShippingDao shippingDao;
	
	
	@Override
	public Shipping findByshippingId(int id) {
	Shipping s = shippingDao.findByshippingId(id);
		
	if(s!=null) {
		return s;
	}
	return null;
	}


	@Override
	public boolean Save(Shipping s) {
		Shipping shipp = shippingDao.save(s);
		
		if(shipp!=null) {
			return true;
			
		}
		
		return false;
	}

}
