package com.cg.capstore.dto;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component
@Entity
@Table(name="wishlist1")
public class Wishlist {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="see")
	@SequenceGenerator(name="see",sequenceName="swq",initialValue=1,allocationSize=1)
	private int wishlistId;
	private String prod_name; 
	
	private String prod_Id;
	
	private int price;
	
	public Wishlist() {
		// TODO Auto-generated constructor stub
	}

	public String getProd_name() {
		return prod_name;
	}

	public void setProd_name(String prod_name) {
		this.prod_name = prod_name;
	}

	public String getProd_Id() {
		return prod_Id;
	}

	public void setProd_Id(String prod_Id) {
		this.prod_Id = prod_Id;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Wishlist [prod_name=" + prod_name + ", prod_Id=" + prod_Id + ", price=" + price + "]";
	}
	
}