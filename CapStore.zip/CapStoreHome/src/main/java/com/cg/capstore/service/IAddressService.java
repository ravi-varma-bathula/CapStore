package com.cg.capstore.service;

import java.util.List;

import com.cg.capstore.dto.Address;

public interface IAddressService {
	List<Address> findBycustomerId(int customerId);
	public void save(Address address);
	
}
