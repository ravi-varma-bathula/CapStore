package com.cg.capstore.service;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.dao.OrderDao;
import com.cg.capstore.dao.TransactionDao;
import com.cg.capstore.dto.GenerateInvoice;
import com.cg.capstore.dto.Order;
import com.cg.capstore.dto.RefundMoney;
import com.cg.capstore.dto.ReturnOrders;
import com.cg.capstore.dto.Transaction;

@Service("transactionService")
public class TransactionServiceImpl implements TransactionService{
@Autowired
	TransactionDao transactionDao;
	

	public Transaction findBytransactionId(int transactionId) {
		Transaction tr=transactionDao.findBytransactionId(transactionId);
		return tr;
	}

	public void saveTransaction(Transaction tr) {
		transactionDao.save(tr);
	
	}
	
	
	/*
	public Transaction saveTransaction(Order order, double amount, String modeOfPurchase, String status,
			LocalDate transactionDate) {
		Transaction tr= new Transaction();
		
		tr.setAmount(amount);
		tr.setModeOfPurchase(modeOfPurchase);
		tr.setOrder(order);
		tr.setStatus(status);
		tr.setTransactionDate(transactionDate);
		transactionDao.save(tr);
	return tr;
	}
*/
	@Autowired
	OrderDao orderDao;
	
	@Override
	public Order findByorderId(int orderId) {
	Order o = orderDao.findByorderId(orderId);
		
	if(o!=null) {
		
		
		return o;
	}
	return null;
	}	
	
}
