package com.cg.capstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.capstore.dto.Order;
@Repository("orderDao")
public interface OrderDao extends JpaRepository<Order, Integer>
{

	Order findByorderId(int orderId);

	
	
}
