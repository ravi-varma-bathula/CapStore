package com.cg.capstore.dto;

import java.time.LocalDate;

import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Component
@Table(name = "caporder1")
public class Order {
	@Override
	public String toString() {
		return "Order" + orderId + ", pdtid=" + pdtid + ", Pdtname=" + Pdtname + ", price=" + price
				+ ", customerid=" + customerid + ", orderDate=" + orderDate + ", deliveredDate=" + deliveredDate + "]";
	}

	@Id
	@GeneratedValue(generator = "cust1", strategy = GenerationType.SEQUENCE)
	@SequenceGenerator(name = "cust1", sequenceName = "Order1", initialValue = 1, allocationSize = 1)
	private int orderId;
	private int pdtid;
	private String Pdtname;
	private Integer price;
	private int customerid;
	
	@JsonFormat(pattern = "dd-MMM-yyyy")
	private LocalDate orderDate;
	@JsonFormat(pattern = "dd-MMM-yyyy")
	private LocalDate deliveredDate;

	public int getCustomerid() {
		return customerid;
	}

	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}

	

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public LocalDate getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}

	public LocalDate getDeliveredDate() {
		return deliveredDate;
	}

	public void setDeliveredDate(LocalDate deliveredDate) {
		this.deliveredDate = deliveredDate;
	}

	public int getPdtid() {
		return pdtid;
	}

	public void setPdtid(int pdtid) {
		this.pdtid = pdtid;
	}

	public String getPdtname() {
		return Pdtname;
	}

	public void setPdtname(String pdtname) {
		Pdtname = pdtname;
	}

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

	public Order() {
		super();
	}

	public Order(int pdtid, String pdtname, Integer price, int customerid, LocalDate orderDate,
			LocalDate deliveredDate) {
		super();
		this.pdtid = pdtid;
		Pdtname = pdtname;
		this.price = price;
		this.customerid = customerid;
		this.orderDate = orderDate;
		this.deliveredDate = deliveredDate;
	}


}

// package com.cg.capstore.dto;
//
// import javax.persistence.Entity;
// import javax.persistence.Id;
// import javax.persistence.Table;
//
// import org.springframework.stereotype.Component;
//
// @Entity
// @Component
// @Table(name="CapstoreOrder")
// public class Order
// {
// @Id
// private int orderid;
// private int pdtid;
// private String Pdtname;
// private Integer price;
// private String qty;
//
//
//
//
// public int getPdtid() {
// return pdtid;
// }
// public void setPdtid(int pdtid) {
// this.pdtid = pdtid;
// }
//
// public int getOrderid() {
// return orderid;
// }
// public void setOrderid(int orderid) {
// this.orderid = orderid;
// }
//
// public String getPdtname() {
// return Pdtname;
// }
// public void setPdtname(String pdtname) {
// Pdtname = pdtname;
// }
// public Integer getPrice() {
// return price;
// }
// public void setPrice(Integer price) {
// this.price = price;
// }
// public String getQty() {
// return qty;
// }
// public void setQty(String qty) {
// this.qty = qty;
// }
//
// }
