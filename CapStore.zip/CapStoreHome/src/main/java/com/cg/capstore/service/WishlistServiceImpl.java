package com.cg.capstore.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.cg.capstore.dao.WishlistDao;
import com.cg.capstore.dto.Wishlist;

@Service("service")
@Transactional
public class WishlistServiceImpl implements WishlistService{

	@Autowired
	WishlistDao dao;
	
	@Override
	public List<Wishlist> getAll() {
		return dao.findAll();
	}

	@Override
	public boolean delete(String user_Id) {
		
		 dao.deleteById(user_Id);
		 return true;
	}

	@Override
	public Wishlist add(Wishlist Wishlist) {
		// TODO Auto-generated method stub
		return dao.save(Wishlist);
	}

	@Override
	public Wishlist getWishlistDetails(String user_Id) {
		// TODO Auto-generated method stub
		Wishlist ws= dao.getOne(user_Id);
		return ws;
	}

	@Override
	public Wishlist update(Wishlist Wishlist) {
		// TODO Auto-generated method stub
	 return dao.save(Wishlist);
	}

	

}
