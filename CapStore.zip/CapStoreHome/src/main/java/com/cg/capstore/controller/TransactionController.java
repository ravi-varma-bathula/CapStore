package com.cg.capstore.controller;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.capstore.dto.Address;
import com.cg.capstore.dto.GenerateInvoice;
import com.cg.capstore.dto.Order;
import com.cg.capstore.dto.RefundMoney;
import com.cg.capstore.dto.ReturnOrders;
import com.cg.capstore.dto.Transaction;
import com.cg.capstore.service.IAddressService;
import com.cg.capstore.service.TransactionService;

@Controller
public class TransactionController {

	@Autowired	
	IAddressService addressService;
	
	@Autowired
	TransactionService transactionService;

	@RequestMapping("/TransactionPage")
	public ModelAndView ModeOfTransaction(HttpServletRequest request) {
	
		System.out.println("From Confirm ");
		HttpSession session=request.getSession();
		List<Address> list = addressService.findBycustomerId(1);
		if(list!=null) {
			
			session.setAttribute("Addresslist", list);
			
		}
		
		
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("TransactionPage");
		return modelAndView;

	}

	@RequestMapping("/card")
	public ModelAndView Card(HttpServletRequest request) {

		HttpSession session = request.getSession();
		session.setAttribute("mode", "Card");
		ModelAndView modelAndView = new ModelAndView();

		modelAndView.setViewName("Card");
		return modelAndView;
	}

	@RequestMapping("/net")
	public ModelAndView Online(HttpServletRequest request) {

		HttpSession session = request.getSession();
		session.setAttribute("mode", "NetBanking");
		double cartAmount = (double) session.getAttribute("totalprice");
		Transaction newTransaction = new Transaction();
		newTransaction.setAmount(cartAmount);
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate now = LocalDate.now();
		newTransaction.setTransactionDate((now));
		
		String mode = (String) session.getAttribute("mode");
		newTransaction.setModeOfPurchase(mode);
	
		Order getOrderDetails = (Order) session.getAttribute("orderDetails");
		newTransaction.setOrder(getOrderDetails);
		
		
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("TID" ,newTransaction.getTransactionId());
		session.setAttribute("TID", newTransaction.getTransactionId());
		modelAndView.setViewName("NetBanking");
		return modelAndView;

	}

	@RequestMapping("/cod")
	public ModelAndView cod(HttpServletRequest request) {
		ModelAndView modelAndView = new ModelAndView();
		
		
		HttpSession session = request.getSession();
		session.setAttribute("mode", "COD");
		
		
		double cartAmount = (double) session.getAttribute("totalprice");

		Transaction newTransaction = new Transaction();
		newTransaction.setAmount(cartAmount);

		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate now = LocalDate.now();
		newTransaction.setTransactionDate((now));

		System.out.println(dtf.format(now));

		String mode = (String) session.getAttribute("mode");
		newTransaction.setModeOfPurchase(mode);
	
		Order getOrderDetails = (Order) session.getAttribute("orderDetails");
		System.out.println("Order Details Fromm Session arec "+getOrderDetails);
		
		
		newTransaction.setOrder(getOrderDetails);

		newTransaction.setStatus("paid On Delivery");
		transactionService.saveTransaction(newTransaction);

		
		modelAndView.addObject("TID" ,newTransaction.getTransactionId());
		session.setAttribute("TID", newTransaction.getTransactionId());
		modelAndView.setViewName("SaveTransaction");
		return modelAndView;
		
	}

	@RequestMapping("/invoice")
	public String getInvoice() {
		return "invoice";
	}
	
	@RequestMapping("/savetransaction")
	public ModelAndView invoicePage(HttpServletRequest request) {

		HttpSession session = request.getSession();

		double cartAmount = (double) session.getAttribute("totalprice");

		Transaction newTransaction = new Transaction();
		newTransaction.setAmount(cartAmount);

		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate now = LocalDate.now();
		newTransaction.setTransactionDate((now));

		System.out.println(dtf.format(now));

		String mode = (String) session.getAttribute("mode");
		newTransaction.setModeOfPurchase(mode);
	
		Order getOrderDetails = (Order) session.getAttribute("orderDetails");
		System.out.println("Order Details Fromm Session arec "+getOrderDetails);
		
		
		newTransaction.setOrder(getOrderDetails);

		newTransaction.setStatus("paid");
		transactionService.saveTransaction(newTransaction);

		ModelAndView modelAndView = new ModelAndView();
	
		modelAndView.addObject("TID" ,newTransaction.getTransactionId());
		session.setAttribute("TID", newTransaction.getTransactionId());
		modelAndView.setViewName("SaveTransaction");
		return modelAndView;
	}

}
