package com.cg.capstore.service;

import java.util.Date;
import java.util.List;
import com.cg.capstore.dto.coupon;

public interface ICouponService {

	List<coupon> getAllCoupons();

	coupon validateCoupon(String name);

	coupon addCoupon(String cname, double amount, String desc, Date idate, Date edate);

	coupon findBycouponCode(String name);

	void deleteCoupon(String couponid);
}
